Meteor.startup(function () {
  $.material.init();
});
